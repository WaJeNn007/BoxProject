#!/bin/bash
echo "Starting"
java -cp bin BoxProject.Driver
echo "Done"
